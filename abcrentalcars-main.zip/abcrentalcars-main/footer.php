<footer id="footer">
				<div id="footer-menu">
					<div class="footer-content">
						<div class="footer-navbar">
							<div class="footer-nav">
								<h3 class="widget-title">Renty</h3>
								<ul>
									<li><a href="01-home-v1.html" title="">Home</a></li>
									<li><a href="#" title="">Privacy</a></li>
									<li><a href="#" title="">Services</a></li>
									<li><a href="#" title="">Partners</a></li>
									<li><a href="#" title="">News</a></li>
								</ul>
							</div>
							<div class="footer-nav">
								<h3 class="widget-title">About</h3>
								<ul>
									<li><a href="#" title="">Latest News</a></li>
									<li><a href="#" title="">Press Releases</a></li>
									<li><a href="#" title="">Careers</a></li>
									<li><a href="#" title="">Terms of Use</a></li>
								</ul>
							</div>
							<div class="footer-nav">
								<h3 class="widget-title">Support</h3>
								<ul>
									<li><a href="#" title="">Contact Us</a></li>
									<li><a href="#" title="">Find Your Invoice</a></li>
									<li><a href="10-faq.html" title="">FAQ</a></li>
								</ul>
							</div>
						</div>
						<div class="widget-area">
							<div class="recent_tweets footer-widget-single">
								<h3>Recent tweets</h3>
								<div class="recent_tweets_content"><a href="#" title="">@bestwebsoft</a> velit, vitae tincidunt orci. Proin vitae auctor lectus.</div>
								<div class="recent_tweets_url"><a href="#" title="">https://bestwebsoft.com</a></div>
								<div class="recent_tweets_time">posted 2 days ago</div>
							</div>
						</div>
						<div class="custom-info footer-widget-single">
							<div class="support">
								<img src="images/support-icon.png" alt="" />
								<div>
									<div class="title">Online support</div>
									<div class="phone">+1 (555) 555 - 28 - 28</div>
									<div class="email"><a href="#" title="">support@bestwebsoft.zendesk.com</a></div>
								</div>
								<div class="clear"></div>
							</div>
						</div>
						<div class="clear"></div>
					</div><!-- .footer-content -->
				</div>
			</footer><!--end:footer-->