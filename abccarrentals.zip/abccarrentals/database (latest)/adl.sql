-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2022 at 01:12 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adl`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `profile` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `requirement` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `profile`, `surname`, `firstname`, `middlename`, `email`, `contact`, `username`, `password`, `user_type`, `requirement`, `status`, `date`) VALUES
(1, '', 'Dela Cruz', 'Juan', 'Smith', 'juandelacruz@gmail.com', '09956425669', 'administrator', '$2y$10$tFXvO4F6WQxJsvNoezBmeeHuIqYoEq6zhTSSA3T/nVnC/li8d5UGO', 'Administrator', '', 1, '2022-06-07 18:59:03'),
(7, '', 'Reroma', 'Ansel John', 'Alolod', 'ajreroma@gmail.com', '09213782648', 'ajreroma', '$2y$10$3rLibf6KBFsClbO38BvB0..eVxrxRQC4qaD5GzvqezxGj7BsD7iKi', 'Customer', 'id.jpg', 1, '2022-06-21 23:12:52'),
(8, '', 'Hernandez', 'Nick', 'Liwag', 'nick@gmail.com', '09217384917', 'nickhernandez', '$2y$10$mGAHsziD4cqTHGy4Uobi4OZhwMYao/Vo2P4jlps8ePnd5wsNUb3X.', 'Macro', 'id2.jpg', 1, '2022-06-21 23:15:47'),
(9, '', 'Bravo', 'Johny', 'Stephenson', 'johnybravo@gmail.com', '09217384619', 'johnybravo242', '$2y$10$HaVX3/8iheDLBTXmhAZWtOQPfI/L2jxjipHC7nB1qPhHR/6HpJODW', 'Micro', 'id3.jpg', 1, '2022-06-21 23:55:59'),
(10, '', 'Lorenzo', 'Gian', 'Pasusani', 'Gian_lorenzo@gmail.om', '09217384917', 'gian123', '$2y$10$rKT1Kwt/fHcOJcvSxvRpHeeA.kENhqF8d/7hbLME4NtcSmt2pGUGy', 'Customer', 'id2.jpg', 1, '2022-06-22 02:14:10'),
(11, '', 'Ricardo', 'Raven Faith', 'Santos', 'raven@gmail.com', '09217384917', 'raven', '$2y$10$r6VOQzjnv5FK/FDpZWWQfu7nuaNVYhhFn/vQFgwooMfu.vBD7ArPy', 'Customer', 'id3.jpg', 1, '2022-06-22 03:09:30'),
(12, '', 'Ramos', 'Mary Stephanie', 'Roxas', 'mary@gmail.com', '09214619385', 'mary', '$2y$10$LFCptvhyo2OM8TJUeFM9CeJz3rJcPpooViU35Gfd.1lmspo0UqC2W', 'Macro', 'permit1.jpg', 1, '2022-06-22 03:18:52'),
(13, '', 'Santos', 'Jillian Marie', 'Lopez', 'jillian@gmail.com', '09128461937', 'jillian', '$2y$10$7kVMwmxHPQwtJHamj47Ay.RWimVTDPfw20OU4j0Q3ojNsvTiAw2RK', 'Customer', 'license1.jpg', 1, '2022-06-22 03:22:53'),
(14, '', 'Divina', 'Maria Francheska', 'Divina', 'mariafrancheska@gmail.com', '09214619385', 'mariafrancheska', '$2y$10$3nnJVIAq1eIPEH8vgI.LQeTQCO6/PVyHouIpgzNtp2lJqYZeFFElW', 'Customer', 'id5.png', 1, '2022-06-22 15:26:40'),
(15, '', 'Reyes', 'John Mark', 'Lozano', 'johnmark@gmail.com', '09214619385', 'johnmarklozano', '$2y$10$wI/y7Do5i1JjcXJaKbDCee5CtTf.lLDtEHJ3WqCkaFMTPRYgbwyIC', 'Macro', 'permit3.jpg', 1, '2022-06-22 15:29:31'),
(16, '', 'Magsaysay', 'Mae Ann', 'Laguna', 'mae@gmail.com', '09214619385', 'mae', '$2y$10$kQJrfBD6.z8VIcx2ekBNJe0caUmXVfpra3QQpZrFOiFDg2w.v4GpW', 'Micro', 'id7.jpg', 1, '2022-06-23 01:57:10'),
(17, '', 'Manalad', 'Keane', 'Ryane', 'ryane@gmail.com', '09214619385', 'kay', '$2y$10$SdK5B4o4h.12w6eGNp8RXOBYgmzSSnNERLw7eiECJRTuolp1KDU4K', 'Customer', 'id5.png', 1, '2022-06-23 02:26:37'),
(18, '', 'Santos', 'Maria', 'Klorena', 'maeannee@gmail.com', '09214619385', 'mayan', '$2y$10$cSaomZ1H.ZyMdV/ZteZEU.ZPvxM1AtOn8rw2MY88IVLe8aAO/kTX6', 'Micro', 'permit1.jpg', 1, '2022-06-23 02:29:50'),
(19, '', 'Placido', 'Franzell', 'Sales', 'franzelle@gmail.com', '09214619385', 'franzelle', '$2y$10$HqbuT1beMNvzUBe1mXZj..geWa2ueDDcKD/aHAi14IeQqdc5Du7YG', 'Customer', 'id7.jpg', 1, '2022-06-24 01:43:20'),
(20, '', 'Reyes', 'Kate', 'Flores', 'kate@gmail.com', '09214619385', 'kate', '$2y$10$FV038JxT7Lq2bdNFCEebION5pcXXPKq3feOhc7/HIMLHuYji61wwy', 'Macro', 'permit4.jpg', 0, '2022-06-24 01:47:50'),
(21, '', 'Caranza', 'Cherry', 'Sonas', 'cherry@gmail.com', '09214619385', 'cherry', '$2y$10$nkhz6zHvlXRkhy6epSj7vuiKPT8R49ZPuS0bDkZ4Nrvu.odeyxuoq', 'Customer', 'id6.jpg', 0, '2022-06-24 02:48:46'),
(22, '', 'wdadw', 'awdwd', 'wadad', 'dwad@gmail.com', '09214619385', 'master', '$2y$10$1yF0cD/JhnhcMyruv5m9cetsVBwYZ0vn7umckwymx108eQDLAzduW', 'Customer', 'license2.jpg', 0, '2022-06-24 08:34:51');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(11) NOT NULL,
  `accounts_id` int(11) NOT NULL,
  `images` varchar(255) NOT NULL,
  `manufacturer` varchar(255) NOT NULL,
  `no_of_doors` int(11) NOT NULL,
  `fuel_tank_capacity` varchar(255) NOT NULL,
  `seating_capacity` varchar(255) NOT NULL,
  `transmission_type` varchar(255) NOT NULL,
  `gear_box` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `fuel_type` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `accounts_id`, `images`, `manufacturer`, `no_of_doors`, `fuel_tank_capacity`, `seating_capacity`, `transmission_type`, `gear_box`, `model`, `color`, `year`, `rate`, `fuel_type`, `date`) VALUES
(30, 8, '86.jpg', 'Toyota', 2, '40L', '4', 'Manual', '8', '86', 'Black', 2020, 5500, 'Gas', '2022-06-24 05:22:05'),
(31, 8, 'avanza.jpg', 'Toyota', 5, '35L', '7', 'Automatic', '4', 'Avanza', 'Black', 2018, 6500, 'Gas', '2022-06-24 05:28:11'),
(32, 8, 'montero.jpg', 'Mitsubishi', 5, '50L', '8', 'Automatic', '7', 'Montero Sport', 'White', 2018, 5700, 'Diesel', '2022-06-24 05:29:32'),
(33, 8, 'fortuner.jpg', 'Toyota', 5, '46L', '7', 'Manual', '8', 'Fortuner', 'White', 2020, 9500, 'Diesel', '2022-06-24 06:27:33'),
(34, 8, 'nissan_urvan_nv350_25l_premium_1630167267_d9b6afa1_progressive.jpg', 'Nissan', 4, '50L', '12', 'Automatic', '8', 'Urvan NV350 Premium', 'Silver', 2021, 6700, 'Diesel', '2022-06-24 06:28:28'),
(35, 8, 'supergrandia.jpeg', 'Toyota', 5, '50L', '7', 'Automatic', '7', 'Hiace Super Grandia', 'White', 2018, 6200, 'Diesel', '2022-06-24 06:29:17'),
(36, 16, 'w2.jpg', 'Toyota', 4, '35L', '5', 'Automatic', '4', 'Wigo G', 'Yellow', 2021, 1200, 'Gas', '2022-06-24 06:30:12'),
(37, 16, 'v4.jpg', 'Toyota', 5, '35L', '5', 'Manual', '4', 'Vios', 'Red', 2020, 2500, 'Gas', '2022-06-24 06:31:12'),
(38, 16, 'civ2.jpg', 'Honda', 5, '35L', '5', 'Manual', '4', 'Civic', 'Silver', 2015, 1100, 'Gas', '2022-06-24 06:31:53'),
(39, 16, 'almera.jpg', 'Nissan', 5, '35L', '5', 'Manual', '4', 'Almera', 'Silver', 2020, 1460, 'Gas', '2022-06-24 06:33:09');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `position` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `reference`, `sender`, `receiver`, `message`, `position`, `date`) VALUES
(1, 'ADL541944', 'John David Lozano', 'David James Sadia Lozano', 'Thank you for your reservation. Your reference code is ADL541944', 0, '2022-06-16 08:43:29'),
(8, 'ADL541944', 'David James Sadia Lozano', 'John David Lozano', 'zxczxc23213', 1, '2022-06-16 09:15:43'),
(9, 'ADL541944', 'David James Sadia Lozano', 'John David Lozano', 'This is it', 1, '2022-06-16 09:15:53'),
(10, 'ADL806694', 'David James Sadia Lozano', 'John David Lozano', 'Hello', 1, '2022-06-16 09:16:10'),
(11, 'ADL113174', 'John David Lozano', 'David James Sadia Lozano', 'Thank you for your reservation. Your reference code is ADL113174', 0, '2022-06-16 09:57:17'),
(12, 'ADL820584', 'John David Lozano', 'David James Sadia Lozano', 'Thank you for your reservation. Your reference code is ADL820584', 0, '2022-06-16 11:10:53'),
(13, 'ADL820584', 'John David Lozano2', 'John David Lozano', 'this is great', 1, '2022-06-16 11:46:24'),
(14, 'ADL820584', 'John David Lozano', 'John David Lozano', 'zxczxc', 0, '2022-06-16 11:54:25'),
(15, 'ADL820584', 'John David Lozano2', 'John David Lozano', '1231231231', 1, '2022-06-16 11:54:47'),
(16, 'ADL820584', 'John David Lozano', 'John David Lozano', 'Hello world', 0, '2022-06-16 12:03:50'),
(17, 'ADL820584', 'John David Lozano', 'John David Lozano', 'test', 0, '2022-06-16 12:04:12'),
(18, 'ADL820584', 'John David Lozano', 'John David Lozano', 'zxc', 0, '2022-06-16 12:21:48'),
(19, 'ADL724204', 'Nick Liwag Hernandez', 'Gian Pasusani Lorenzo', 'Thank you for your reservation. Your reference code is ADL724204', 0, '2022-06-22 02:15:46'),
(20, 'ADL724204', 'Gian Pasusani Lorenzo', 'Nick Liwag Hernandez', 'fsdfsdf', 1, '2022-06-22 02:16:03'),
(21, 'ADL724204', 'Nick Liwag Hernandez', 'Nick Liwag Hernandez', 'reter', 0, '2022-06-22 02:16:38'),
(22, 'ADL724204', 'Gian Pasusani Lorenzo', 'Nick Liwag Hernandez', 'hiii', 1, '2022-06-22 02:41:40'),
(23, 'ADL677815', 'Nick Liwag Hernandez', 'Calixto Olaaga Olago', 'Thank you for your reservation. Your reference code is ADL677815', 0, '2022-06-22 03:12:24'),
(24, 'ADL677815', 'Calixto Olaaga Olago', 'Nick Liwag Hernandez', 'hoy', 1, '2022-06-22 03:13:02'),
(25, 'ADL677815', 'Nick Liwag Hernandez', 'Nick Liwag Hernandez', 'hoy ka rin', 0, '2022-06-22 03:13:15'),
(26, 'ADL632685', 'Mary Marife Gagala', 'Joey Benitez Vergom', 'Thank you for your reservation. Your reference code is ADL632685', 0, '2022-06-22 03:25:42'),
(27, 'ADL632685', 'Joey Benitez Vergom', 'Mary Marife Gagala', 'Hi\r\n', 1, '2022-06-22 03:26:15'),
(28, 'ADL632685', 'Joey Benitez Vergom', 'Mary Marife Gagala', 'Hello', 1, '2022-06-22 03:26:23'),
(29, 'ADL632685', 'Mary Marife Gagala', 'Mary Marife Gagala', 'Thank you!', 0, '2022-06-22 03:26:32'),
(30, 'ADL632685', 'Joey Benitez Vergom', 'Mary Marife Gagala', 'I want to cancel', 1, '2022-06-22 03:27:02'),
(31, 'ADL632685', 'Mary Marife Gagala', 'Mary Marife Gagala', 'Okay Sir', 0, '2022-06-22 03:27:22'),
(32, 'ADL936555', 'Nick Liwag Hernandez', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL936555', 0, '2022-06-22 10:32:22'),
(33, 'ADL632685', 'Mary Stephanie Roxas Ramos', 'Mary Stephanie Roxas Ramos', 'Hello', 0, '2022-06-22 12:55:36'),
(34, 'ADL995144', 'John Mark Lozano Reyes', 'Maria Francheska Divina Divina', 'Thank you for your reservation. Your reference code is ADL995144', 0, '2022-06-22 15:33:14'),
(35, 'ADL995144', 'Maria Francheska Divina Divina', 'John Mark Lozano Reyes', 'Hello', 1, '2022-06-22 15:34:26'),
(36, 'ADL995144', 'John Mark Lozano Reyes', 'John Mark Lozano Reyes', 'Hi', 0, '2022-06-22 15:34:37'),
(37, 'ADL995144', 'Maria Francheska Divina Divina', 'John Mark Lozano Reyes', 'can I pay in Gcash?', 1, '2022-06-22 15:35:45'),
(38, 'ADL195844', 'Maria Klorena Santos', 'Keane Ryane Manalad', 'Thank you for your reservation. Your reference code is ADL195844', 0, '2022-06-23 02:33:13'),
(39, 'ADL195844', 'Keane Ryane Manalad', 'Maria Klorena Santos', 'Hello Sir', 1, '2022-06-23 02:33:36'),
(40, 'ADL195844', 'Maria Klorena Santos', 'Maria Klorena Santos', 'Hi', 0, '2022-06-23 02:33:45'),
(41, 'ADL555308', 'Mae Ann Laguna Magsaysay', 'Keane Ryane Manalad', 'Thank you for your reservation. Your reference code is ADL555308', 0, '2022-06-23 02:55:24'),
(42, 'ADL755330', 'Mae Ann Laguna Magsaysay', 'Franzell Sales Placido', 'Thank you for your reservation. Your reference code is ADL755330', 0, '2022-06-24 02:26:27'),
(43, 'ADL755330', 'Mae Ann Laguna Magsaysay', 'Mae Ann Laguna Magsaysay', 'Hi', 0, '2022-06-24 02:26:54'),
(44, 'ADL755330', 'Franzell Sales Placido', 'Mae Ann Laguna Magsaysay', 'Hi\r\n', 1, '2022-06-24 02:26:59'),
(45, 'ADL161130', 'Nick Liwag Hernandez', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL161130', 0, '2022-06-24 03:37:43'),
(46, 'ADL611690', 'Nick Liwag Hernandez', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL611690', 0, '2022-06-24 03:38:05'),
(47, 'ADL662072', 'Johny Stephenson Bravo', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL662072', 0, '2022-06-24 03:39:43'),
(48, 'ADL613241', 'Mae Ann Laguna Magsaysay', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL613241', 0, '2022-06-24 03:45:24'),
(49, 'ADL545026', 'Nick Liwag Hernandez', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL545026', 0, '2022-06-24 03:46:05'),
(50, 'ADL931135', 'Mae Ann Laguna Magsaysay', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL931135', 0, '2022-06-24 04:01:11'),
(51, 'ADL118638', 'Maria Klorena Santos', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL118638', 0, '2022-06-24 04:04:34'),
(52, '36400', 'Nick Liwag Hernandez', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is 36400', 0, '2022-06-24 04:08:56'),
(53, '100100', 'Nick Liwag Hernandez', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is 100100', 0, '2022-06-24 04:09:11'),
(54, '22000', 'Mary Stephanie Roxas Ramos', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is 22000', 0, '2022-06-24 04:10:26'),
(55, 'ADL620696', 'Maria Klorena Santos', 'Ansel John Alolod Reroma', 'Thank you for your reservation. Your reference code is ADL620696', 0, '2022-06-24 04:10:46');

-- --------------------------------------------------------

--
-- Table structure for table `manufacturers`
--

CREATE TABLE `manufacturers` (
  `id` int(11) NOT NULL,
  `manufacturer` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manufacturers`
--

INSERT INTO `manufacturers` (`id`, `manufacturer`, `logo`) VALUES
(1, 'Mitsubishi', ''),
(2, 'Honda', ''),
(3, 'Toyota', ''),
(4, 'Suzuki', ''),
(5, 'Isuzu', ''),
(6, 'Nissan', ''),
(7, 'Kia', ''),
(8, 'Hyundai', ''),
(9, 'Foton', ''),
(10, 'Chevrolet', ''),
(11, 'Mazda', ''),
(12, 'Ford', ''),
(13, 'MG', ''),
(14, 'Chery', ''),
(15, 'BMW', ''),
(16, 'Audi', ''),
(17, 'Geely', ''),
(18, 'Volvo', ''),
(19, 'Volkswagen', '');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `owners_id` int(11) NOT NULL,
  `cars_id` int(11) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `rate_per_day` int(11) NOT NULL,
  `days_rented` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `reason` longtext DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manufacturers`
--
ALTER TABLE `manufacturers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `manufacturers`
--
ALTER TABLE `manufacturers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
