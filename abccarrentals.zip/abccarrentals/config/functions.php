<?php
include 'config.php';

function post($data) {
    global $db;
    return $db->real_escape_string($_POST[$data]);
}

function register($register_surname,$register_firstname,$register_middlename,$register_email,$register_contact,$register_username,$register_password,$user_type) {
    global $db;
    $checker = $db->query("SELECT * FROM accounts WHERE email = '$register_email'");
    if($checker->num_rows > 0) {
        echo "<script>
alert('Email already exists');
</script>";
    } else {
        $requirement  = $_FILES['requirement']['name'];
        $location = $user_type == 'Customer' ? 'license' : 'permit';
        $db->query("INSERT INTO accounts (surname,firstname,middlename,email,contact,username,password,user_type,requirement) VALUES ('$register_surname','$register_firstname','$register_middlename','$register_email','$register_contact','$register_username','$register_password','$user_type','$requirement')");
        move_uploaded_file($_FILES['requirement']['tmp_name'],'images/'.$location.'/'.$_FILES['requirement']['name']);
        echo "<script>
alert('Account has been successfully created. Pending for Approval');
</script>";
    }
}

function get_account_details($id) {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE id = $id")->fetch_assoc();
}

function update_profile($surname,$firstname,$middlename,$email,$contact) {
    global $db;
    $query = $db->query("UPDATE accounts SET surname = '$surname', firstname = '$firstname', middlename = '$middlename', email = '$email', contact = '$contact' WHERE id = ".$_SESSION['customer_id']);
    if($query) {
        header('location: profile.php?success=true&message='.urlencode('Your information has been updated')); 
    }
}
//admin
function update_admin_profile($surname,$firstname,$middlename,$email,$contact) {
    global $db;
    $query = $db->query("UPDATE accounts SET surname = '$surname', firstname = '$firstname', middlename = '$middlename', email = '$email', contact = '$contact' WHERE id = ".$_SESSION['admin_id']);
    if($query) {
        header('location: profile.php?success=true&message='.urlencode('Your information has been updated')); 
    }
}
//admin
function update_admin_password($old_password,$new_password,$confirm_new_password) {
    global $db;
    $data = get_account_details($_SESSION['admin_id']);
    
    if(password_verify($old_password,$data['password'])) {
        if($new_password == $confirm_new_password) {
            $password   = password_hash($new_password,PASSWORD_DEFAULT);
            $query      = $db->query("UPDATE accounts SET password = '$password' WHERE id = ".$_SESSION['admin_id']);
            if($query) {
                header('location: profile.php?success=true&message='.urlencode('Password has been changed.')); 
            }
        } else {
            header('location: profile.php?success=false&message='.urlencode('New password and confirm new password is mismatched')); 
        }
    } else {
        header('location: profile.php?success=false&message='.urlencode('Old password is incorrect')); 
    }
}
function update_owner_password($old_password,$new_password,$confirm_new_password) {
    global $db;
    $data = get_account_details($_SESSION['owners_id']);
    
    if(password_verify($old_password,$data['password'])) {
        if($new_password == $confirm_new_password) {
            $password   = password_hash($new_password,PASSWORD_DEFAULT);
            $query      = $db->query("UPDATE accounts SET password = '$password' WHERE id = ".$_SESSION['owners_id']);
            if($query) {
                header('location: profile.php?success=true&message='.urlencode('Password has been changed.')); 
            }
        } else {
            header('location: profile.php?success=false&message='.urlencode('New password and confirm new password is mismatched')); 
        }
    } else {
        header('location: profile.php?success=false&message='.urlencode('Old password is incorrect')); 
    }
}

function update_owner_profile($surname,$firstname,$middlename,$email,$contact) {
    global $db;
    $query = $db->query("UPDATE accounts SET surname = '$surname', firstname = '$firstname', middlename = '$middlename', email = '$email', contact = '$contact' WHERE id = ".$_SESSION['owners_id']);
    if($query) {
        header('location: profile.php?success=true&message='.urlencode('Your information has been updated')); 
    }
}



function get_vehicles_details($id) {
    global $db;
    return $db->query("SELECT * FROM cars WHERE id = $id")->fetch_assoc();
}

function update_transactions($id,$reason) {
    global $db;
    $query = $db->query("UPDATE transactions SET reason = '$reason', status = 'Cancelled' WHERE id = $id");
    if($query) {
        header('location: reservation-details.php?id='.$id.'&success=true&message='.urlencode('Transaction has been cancelled'));
    }
}

function update_transaction_status($id,$status) {
    global $db;
    $query = $db->query("UPDATE transactions SET status = '$status' WHERE id = $id");
    if($query) {
        header('location: reservation-details.php?id='.$id.'&success=true&message='.urlencode('Transaction has been approved'));
    }
}

function get_my_cars($owners_id) {
    global $db;
    return $db->query("SELECT * FROM cars WHERE accounts_id = $owners_id");
}

function get_car_details($id) {
    global $db;
    return $db->query("SELECT * FROM cars WHERE id = $id");
}

function get_car_if_exists($id) {
    global $db;
    return $db->query("SELECT * FROM cars WHERE id = $id")->num_rows;
}


function get_chats($reference) {
    global $db;
    return $db->query("SELECT * FROM chat WHERE reference = '$reference'");
}

function get_chats_if_exists($reference) {
    global $db;
    return $db->query("SELECT * FROM chat WHERE reference = '$reference'")->num_rows;
}


function all_manufacturers() {
    global $db;
    return $db->query("SELECT * FROM manufacturers");
}

function get_manufacturers_details($id) {
    global $db;
    return $db->query("SELECT * FROM manufacturers WHERE id = $id");
}

function get_manufacturer_if_exists($id) {
    global $db;
    return $db->query("SELECT * FROM manufacturers WHERE id = $id")->num_rows;
}

function get_vehicles($manufacturers = null,$price_filter = null,$price_range = null,$fuel_type = null) {
    global $db;
    if($manufacturers == 'All') {
        $pre_condition1 = "";
    } else {
        $pre_condition1 = "WHERE manufacturer = '$manufacturers' "; 
    }
    
    if($fuel_type == 'All') {
        $pre_condition2 = "";
    } else {
        if($manufacturers == 'All') {
            $pre_condition2 = "WHERE fuel_type = '$fuel_type'";
        } else {
            $pre_condition2 = " AND fuel_type = '$fuel_type'";
        }
    }

    if($price_range == 0) {
        $pre_condition3 = "";
    } elseif($price_range == 10000) {

        if($manufacturers == 'All' && $fuel_type == 'All') {
            $pre_condition3 = " WHERE rate >= 10000";
        } else {
            $pre_condition3 = " AND rate >= 10000";
        }


    } else {
        $price  = explode('-',$price_range);
        $from   = $price[0];
        $to     = $price[1];
        if($manufacturers == 'All' && $fuel_type == 'All') {
            $pre_condition3 = " WHERE rate >= $from AND rate <= $to ";
        } else {
            $pre_condition3 = " AND rate >= $from AND rate <= $to ";
        }
    }


    $conditions = "$pre_condition1 $pre_condition2 $pre_condition3";

    if($manufacturers != null || $price_filter != null || $price_range != null || $fuel_type != null) {
        $checker = $db->query("SELECT * FROM cars INNER JOIN accounts ON cars.accounts_id = accounts.id $conditions AND accounts.user_type = 'Micro'");
        if($checker->num_rows > 0) {
            return $db->query("SELECT *,cars.id as cars_id FROM cars INNER JOIN accounts ON cars.accounts_id = accounts.id $conditions AND accounts.user_type = 'Micro' ORDER BY rate $price_filter");
        } else {
            return $db->query("SELECT *,cars.id as cars_id FROM cars INNER JOIN accounts ON cars.accounts_id = accounts.id $conditions AND accounts.user_type = 'Macro' ORDER BY rate $price_filter");
        }
    } else {
        return $db->query("SELECT *,cars.id as cars_id FROM cars INNER JOIN accounts ON cars.accounts_id = accounts.id");
    }
}

function secureLogin($username,$password) {
    global $db;
    $check = $db->query("SELECT * FROM accounts WHERE username = '$username' AND user_type = 'Customer' AND status = 1"); // validate if username already exist
    if($check->num_rows > 0) {
        $row = $check->fetch_assoc();
        if(password_verify($password,$row['password'])) {
            $_SESSION['customer_id'] = $row['id'];
            header('location: index.php');
        } else {
            $message = "Invalid Username or Password";
            echo "<script type='text/javascript'>alert('$message');</script>";
        }
    } else {
        $message = "Account does not exist or Account is still pending for Approval";
        echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function ownerLogin($username,$password) {
    global $db;
    $check = $db->query("SELECT * FROM accounts WHERE username = '$username' AND status = 1"); // validate if username already exist
    if($check->num_rows > 0) {
        $row = $check->fetch_assoc();
        if(password_verify($password,$row['password'])) {
            $_SESSION['owners_id'] = $row['id'];
            header('location: dashboard.php');
        } else {
            $message = "Invalid Username or Password";
            echo "<script type='text/javascript'>alert('$message');</script>";
        }
    } else {
        $message = "Account is still pending for Approval";
        echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function adminLogin($username,$password) {
    global $db;
    $check = $db->query("SELECT * FROM accounts WHERE username = '$username' AND user_type = 'Administrator' AND status = 1"); // validate if username already exist
    if($check->num_rows > 0) {
        $row = $check->fetch_assoc();
        if(password_verify($password,$row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            header('location: dashboard.php');
        } else {
            $message = "Invalid Username or Password";
            echo "<script type='text/javascript'>alert('$message');</script>";
        }
    } else {
        $message = "Invalid Username or Password";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function get_all_owners() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE user_type = 'Micro' || user_type = 'Macro'");
}
function get_all_accounts_approved_list_all() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE status = 1 AND user_type = 'Customer' OR status = 1 AND user_type = 'Micro' OR status = 1 AND user_type = 'Macro'");
}

function get_all_accounts_approved_list_customers() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE status = 1 AND user_type = 'Customer'");
}

function get_all_accounts_approved_list_owners() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE status = 1 AND user_type = 'Micro' OR status = 1 AND user_type = 'Macro'");
}

function get_all_accounts_approved() {
    global $db;
    return $db->query("SELECT *,COUNT(id) AS totalapproved FROM accounts WHERE status = 1 AND user_type = 'Customer' OR status = 1 AND user_type = 'Micro' OR status = 1 AND user_type = 'Macro'");
}

function get_all_accounts_not_approved_list_all() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE status = 0 AND user_type = 'Customer' OR status = 0 AND user_type = 'Micro' OR status = 0 AND user_type = 'Macro'");
}

function get_all_accounts_not_approved_list_customers() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE status = 0 AND user_type = 'Customer'");
}

function get_all_accounts_not_approved_list_owners() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE status = 0 AND user_type = 'Micro' OR status = 0 AND user_type = 'Macro'");
}

function get_all_accounts_not_approved() {
    global $db;
    return $db->query("SELECT *,COUNT(id) AS totalnotapproved FROM accounts WHERE status = 0 AND user_type = 'Customer' OR status = 0 AND user_type = 'Micro' OR status = 0 AND user_type = 'Macro'");
}

function get_all_total_profit() {
    global $db;
    return $db->query("SELECT *,SUM(total) AS totalprofit FROM transactions WHERE owners_id = '".$_SESSION['owners_id']."' AND status = 'Approved'");
}

function get_all_total_vehicle() {
    global $db;
    return $db->query("SELECT *,COUNT(id) AS totalvehicle FROM cars WHERE accounts_id = '".$_SESSION['owners_id']."'");
}

function get_all_total_vehicle2() {
    global $db;
    return $db->query("SELECT * FROM cars WHERE accounts_id = '".$_SESSION['owners_id']."'");
}

function get_all_total_bookings() {
    global $db;
    return $db->query("SELECT *,COUNT(id) AS totalbookings FROM transactions WHERE owners_id = '".$_SESSION['owners_id']."' AND status = 'Approved'");
}

function get_all_customers() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE user_type = 'Customer'");
}

function get_all_accounts_approved2() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE status = 1 AND user_type = 'Customer'");
}

function get_all_accounts_notapproved2() {
    global $db;
    return $db->query("SELECT * FROM accounts WHERE status = 0 AND user_type = 'Customer'");
}

function get_all_transactions() {
    global $db;
    return $db->query("SELECT * FROM transactions");
}

function get_all_editpage_aboutus() {
    global $db;
    return $db->query("SELECT * FROM editpage WHERE id = 1");
}

function get_all_editpage_contactus() {
    global $db;
    return $db->query("SELECT * FROM editpage WHERE id = 2");
}

function get_all_editpage_rules() {
    global $db;
    return $db->query("SELECT * FROM editpage WHERE id = 3");
}

function get_all_editpage_termsandconditionscustomer() {
    global $db;
    return $db->query("SELECT * FROM editpage WHERE id = 4");
}

function get_all_editpage_termsandconditionsmacro() {
    global $db;
    return $db->query("SELECT * FROM editpage WHERE id = 5");
}

function get_all_editpage_termsandconditionsmicro() {
    global $db;
    return $db->query("SELECT * FROM editpage WHERE id = 6");
}

function update_status($id,$status) {
    global $db;
    $query = $db->query("UPDATE accounts SET status = $status WHERE id = $id");
    if($query) {
        $message = "Account status has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function update_owner_status($id,$status) {
    global $db;
    $query = $db->query("UPDATE accounts SET status = $status WHERE id = $id");
    if($query) {
        $message = "Account status has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function update_content_status($aboutus) {
    global $db;
    $query = $db->query("UPDATE editpage SET content = '$aboutus' WHERE id = 1 ");
    if($query) {
        $message = "Page Content has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function update_content_termsandconditionscustomer($termsandconditions) {
    global $db;
    $query = $db->query("UPDATE editpage SET content = '$termsandconditions' WHERE id = 4 ");
    if($query) {
        $message = "Page Content has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function update_content_termsandconditionsmacro($termsandconditions) {
    global $db;
    $query = $db->query("UPDATE editpage SET content = '$termsandconditions' WHERE id = 5 ");
    if($query) {
        $message = "Page Content has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function update_content_termsandconditionsmicro($termsandconditions) {
    global $db;
    $query = $db->query("UPDATE editpage SET content = '$termsandconditions' WHERE id = 6 ");
    if($query) {
        $message = "Page Content has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}


function update_content_contactus($contactus) {
    global $db;
    $query = $db->query("UPDATE editpage SET content = '$contactus' WHERE id = 2 ");
    if($query) {
        $message = "Page Content has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function update_content_rules($rules) {
    global $db;
    $query = $db->query("UPDATE editpage SET content = '$rules' WHERE id = 3 ");
    if($query) {
        $message = "Page Content has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}




function transactions($customer_id,$cars_id,$destination,$from,$to,$rate_per_day,$days_rented,$total,$reference,$status) {
    global $db;
    $check = $db->query("SELECT * FROM transactions WHERE customer_id = '$customer_id'  AND `from` = '$from' AND `to` = '$to'"); // validate if username already exist
    if($check->num_rows > 0) {
        $message = "Booking already exists!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    } else {
        $data = get_vehicles_details($cars_id);
        $rowSender  = get_account_details($data['accounts_id']);
        $rowReceiver  = get_account_details($customer_id);
        $owners_id    = $data['accounts_id'];
        $senderName = $rowSender['firstname'].' '.$rowSender['middlename'].' '.$rowSender['surname']; 
        $receiverName = $rowReceiver['firstname'].' '.$rowReceiver['middlename'].' '.$rowReceiver['surname']; 
        $query = $db->query("INSERT INTO transactions (customer_id,owners_id,cars_id,destination,`from`,`to`,rate_per_day,days_rented,total,reference,status) VALUES ('$customer_id','$owners_id','$cars_id','$destination','$from','$to','$rate_per_day','$days_rented','$total','$reference','$status')");

        if($query) {
            $message = 'Thank you for your reservation. Your reference code is '.$reference;
            $db->query("INSERT INTO chat (reference,sender,receiver,message,position) VALUES ('$reference','$senderName','$receiverName','$message',0)");
        }
    }
}

function get_my_transactions($owners_id) {
    global $db;
    return $db->query("SELECT * FROM transactions WHERE owners_id = '$owners_id'"); // validate if username already exist
}

function save_chat($message,$reference,$transaction_id,$customer_id) {
    global $db;
    $rowTransaction = get_transaction_details($transaction_id);
    
    $rowData        = get_vehicles_details($rowTransaction['cars_id']);
    $rowReceiver    = get_account_details($rowData['accounts_id']);
    $rowSender      = get_account_details($customer_id);
    $senderName     = $rowSender['firstname'].' '.$rowSender['middlename'].' '.$rowSender['surname']; 
    $receiverName   = $rowReceiver['firstname'].' '.$rowReceiver['middlename'].' '.$rowReceiver['surname']; 
    $msg            = $message;
    $query = $db->query("INSERT INTO chat (reference,sender,receiver,message,position) VALUES ('$reference','$senderName','$receiverName','$msg',1)");
    if($query) {
        header('location: chat-owner.php?reference='.$reference.'&id='.$transaction_id.'&success=true&message='.urlencode('Message has been sent'));
    }
}

function save_cars($manufacturer,$no_of_doors,$fuel_tank_capacity,$seating_capacity,$transmission_type,$gear_box,$model,$color,$year,$rate,$fuel_type,$rulesandregulations) {
    global $db;
    $accounts_id = $_SESSION['owners_id'];
    $images  = $_FILES['images']['name'];

    $query = $db->query("INSERT INTO cars (accounts_id,images,manufacturer,no_of_doors,fuel_tank_capacity,seating_capacity,transmission_type,gear_box,model,color,`year`,rate,fuel_type,rulesandregulations) VALUES ($accounts_id,'$images','$manufacturer','$no_of_doors','$fuel_tank_capacity','$seating_capacity','$transmission_type','$gear_box','$model','$color','$year','$rate','$fuel_type','$rulesandregulations')");
    if($query) {
        move_uploaded_file($_FILES['images']['tmp_name'],'../../images/vehicles/'.$_FILES['images']['name']);
        $message = "Vehicle Successfully Added!";
            echo "<script type='text/javascript'>alert('$message');</script>";;
    }
}

function update_cars($id,$manufacturer,$no_of_doors,$fuel_tank_capacity,$seating_capacity,$transmission_type,$gear_box,$model,$color,$year,$rate,$fuel_type,$rulesandregulations) {
    global $db;
    $accounts_id = $_SESSION['owners_id'];
    $query = $db->query("UPDATE cars SET manufacturer = '$manufacturer', no_of_doors = '$no_of_doors', fuel_tank_capacity = '$fuel_tank_capacity', seating_capacity = '$seating_capacity', transmission_type = '$transmission_type', gear_box = '$gear_box', model = '$model', color = '$color',`year` = '$year', rate = '$rate', fuel_type = '$fuel_type', rulesandregulations = '$rulesandregulations' WHERE id = $id");
    if($query) {
        $message = "Vehicles has been updated!";
            echo "<script type='text/javascript'>alert('$message');</script>";
    }
}

function update_car_image($id) {
    global $db;
    $accounts_id = $_SESSION['owners_id'];
    $images  = $_FILES['images']['name'];

    $query = $db->query("UPDATE cars SET images = '$images' WHERE id = $id");
    if($query) {
        move_uploaded_file($_FILES['images']['tmp_name'],'../../images/vehicles/'.$_FILES['images']['name']);
        header('location: vehicle-details.php?id='.$id.'&success=true&message='.urlencode('Image has been updated'));
    }
}

function delete_cars($id) {
    global $db;
    $query = $db->query("DELETE FROM cars WHERE id = $id");
    if($query) {
        header('location: my-vehicles.php?success=true&message='.urlencode('Vehicle has been deleted'));
    }
} 


function save_owner_chat($message,$reference,$transaction_id,$owners_id) {
    global $db;
    $rowTransaction = get_transaction_details($transaction_id);
    
    $rowData        = get_vehicles_details($rowTransaction['cars_id']);
    $rowReceiver    = get_account_details($rowData['accounts_id']);
    $rowSender      = get_account_details($owners_id);
    $senderName     = $rowSender['firstname'].' '.$rowSender['middlename'].' '.$rowSender['surname']; 
    $receiverName   = $rowReceiver['firstname'].' '.$rowReceiver['middlename'].' '.$rowReceiver['surname']; 
    $msg            = $message;
    $query = $db->query("INSERT INTO chat (reference,sender,receiver,message,position) VALUES ('$reference','$senderName','$receiverName','$msg',0)");
    if($query) {
        header('location: chat-customer.php?reference='.$reference.'&id='.$transaction_id.'&success=true&message='.urlencode('Message has been sent'));
    }
}



function get_transaction_details($id) {
    global $db;
    return $db->query("SELECT * FROM transactions WHERE id = $id")->fetch_assoc();
}

function upload_drivers_license() {
    global $db;
    $requirement  = $_FILES['requirement']['name'];

    $query = $db->query("UPDATE accounts SET requirement = '$requirement' WHERE id = ".$_SESSION['customer_id']);
    if($query) {
        move_uploaded_file($_FILES['requirement']['tmp_name'],'../images/license/'.$_FILES['requirement']['name']);
        header('location: profile.php?success=true&message='.urlencode('Driver\'s license has been updated'));
    }
}

function upload_business_permit() {
    global $db;
    $requirement  = $_FILES['requirement']['name'];

    $query = $db->query("UPDATE accounts SET requirement = '$requirement' WHERE id = ".$_SESSION['owners_id']);
    if($query) {
        move_uploaded_file($_FILES['requirement']['tmp_name'],'../../images/permit/'.$_FILES['requirement']['name']);
        header('location: profile.php?success=true&message='.urlencode('Business Permit has been updated'));
    }
}



function get_transaction_if_exists($id) {
    global $db;
    return $db->query("SELECT * FROM transactions WHERE id = $id")->num_rows;
}

function get_transactions() {
    global $db;
    return $db->query("SELECT * FROM transactions WHERE customer_id = ".$_SESSION['customer_id']);
}


function encryption($data) {
    $plaintext = $data;
    $key = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
    $iv = openssl_random_pseudo_bytes($ivlen);
    $ciphertext_raw = openssl_encrypt($plaintext, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
    $hmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
    $ciphertext = base64_encode( $iv.$hmac.$ciphertext_raw );
    return $ciphertext;
}

function decryption($data) {
    $c                  = base64_decode($data);
    $key                = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $ivlen              = openssl_cipher_iv_length($cipher="AES-128-CBC");
    $iv                 = substr($c, 0, $ivlen);
    $hmac               = substr($c, $ivlen, $sha2len=32);
    $ciphertext_raw     = substr($c, $ivlen+$sha2len);
    $original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
    $calcmac            = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
    if (hash_equals($hmac, $calcmac))// timing attack safe comparison
    {
        return $original_plaintext;
    }
}